import Link from 'next/link'

export default function AdsPage() {
  return (
    <main className="shell narrow">
      <div className="policy-page card">
        <Link href="/settings" className="back-link">← Settings</Link>
        <h1>Ads & Promotions</h1>
        <p className="muted">A simple place to learn how advertising can work on Husie.</p>
        <section className="card">
          <h2>Create a promotion</h2>
          <p>Promotions can help creators, artists, businesses and community projects reach more people.</p>
          <p><strong>Coming next:</strong> campaign creation, audience selection, budget, duration and performance reporting.</p>
          <button disabled>Ads tools coming soon</button>
        </section>
        <h2>Advertising standards</h2>
        <p>Ads must not be deceptive, fraudulent, threatening or designed to steal passwords or personal information. Promotions should respect Husie’s Community Guidelines.</p>
        <h2>Payments</h2>
        <p>Advertising payments are not enabled yet. Do not send money to anyone claiming to activate ads on your behalf.</p>
        <h2>Transparency</h2>
        <p>When advertising is enabled, promoted content will be clearly identified so users can distinguish it from ordinary posts.</p>
      </div>
    </main>
  )
}
