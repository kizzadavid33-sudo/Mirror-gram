# Mirror Gram — build status (2026-09-18)

## Completed in this package
- Blue/white web UI foundation
- Supplied Mirror Gram logo integrated into web favicon/brand and Expo assets
- Home/feed with photo/video posts, likes, saves, comments and reports
- Discover, profiles, follow controls and Creator Studio
- Messages with conversation creation, text sending and Supabase realtime inserts
- Notifications page and notification triggers in Supabase
- Create-post upload to Supabase Storage with image/video preview
- Public-events map page with approximate-location model
- Live page foundation and realtime authorization in Supabase
- Safety Center, blocking/reporting foundations
- Supabase RLS/security/realtime database foundation already applied to the connected project

## Intentionally not claimed as finished yet
- npm dependency installation/build/runtime verification (waiting for the computer step)
- Native iPhone/Android recording, camera, microphone and push-notification production integration
- Production livestream video transport/CDN/moderation
- Full moderation/admin tooling and abuse/rate-limit infrastructure
- App Store / Google Play release configuration

## Monday verification plan
1. Install Node.js 20+ on the computer.
2. Extract this project.
3. Copy `apps/web/.env.example` to `apps/web/.env.local` and add the Supabase URL + publishable key.
4. Run `npm install`.
5. Run `npm run typecheck:web`.
6. Run `npm run build:web`.
7. Run `npm run dev:web` and test the app in a browser.
8. Test signup/login, posting, media upload, likes/comments/saves, follows, messages/realtime, notifications, reports/blocks, map events and live-page authorization.
